<template>
  <div class="card">
    <img src="https://picsum.photos/1024/400/?image=1" class="card-img-top mt-3" alt="..." />
    <div class="card-body">
      <h5 class="card-title">Blog</h5>
      <p class="card-text">
        Some quick example text to build on the card title and make up the bulk of the card's
        content.
      </p>
      <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
  </div>
</template>

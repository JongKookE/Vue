<template>
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
      <router-link to="/" class="navbar-brand">home</router-link>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link" href="#">Link</a>
          </li>
          <router-link to="/cafe" class="nav-link">Cafe</router-link>

          <router-link to="/mail" class="nav-link">mail</router-link>

          <router-link to="/blog" class="nav-link">Blog</router-link>

          <router-link to="/tellme" class="nav-link">TellMe</router-link>
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              href="#"
              role="button"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              Dropdown
            </a>
            <ul class="dropdown-menu">
              <router-link to="/cafe" class="nav-link">Cafe</router-link>

              <router-link to="/mail" class="nav-link">mail</router-link>

              <router-link to="/blog" class="nav-link">Blog</router-link>

              <router-link to="/tellme" class="nav-link">TellMe</router-link>

              <li><a class="dropdown-item" href="#">Something else here</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled">Disabled</a>
          </li>
        </ul>
        <form class="d-flex" role="search">
          <input
            class="form-control me-2"
            type="search"
            placeholder="Search"
            aria-label="Search"
            v-model="searchKeyword"
          />
          <button class="btn btn-outline-success" @click.prevent="clickSearch()">Search</button>
        </form>
      </div>
    </div>
  </nav>
</template>

<script setup>
import { ref } from 'vue'

const searchKeyword = ref('')
const clickSearch = () => {
  alert(searchKeyword.value)
}
</script>
